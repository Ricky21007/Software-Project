// Resource and request data
let resources = [
    {
      id: '1',
      title: 'Advanced JavaScript Techniques',
      type: 'pdf',
      status: 'available',
      description: 'Comprehensive guide to modern JavaScript development patterns.'
    },
    {
      id: '2',
      title: 'React Performance Workshop',
      type: 'training',
      status: 'available',
      description: 'Live training session on optimizing React applications.'
    },
    {
      id: '3',
      title: 'Full Stack Development',
      type: 'course',
      status: 'available',
      description: 'Complete course covering both frontend and backend development.'
    },
    {
      id: '4',
      title: 'UI/UX Design Principles',
      type: 'pdf',
      status: 'available',
      description: 'Essential principles of modern user interface and experience design.'
    },
    {
      id: '5',
      title: 'Cloud Architecture Fundamentals',
      type: 'course',
      status: 'available',
      description: 'Learn the basics of cloud architecture and deployment strategies.'
    },
    {
      id: '6',
      title: 'Agile Development Workshop',
      type: 'training',
      status: 'available',
      description: 'Interactive workshop on agile methodologies and best practices.'
    },
    {
      id: '7',
      title: 'Cybersecurity Essentials',
      type: 'pdf',
      status: 'available',
      description: 'Comprehensive guide to modern security practices and threat prevention.'
    },
    {
      id: '8',
      title: 'Data Science Bootcamp',
      type: 'course',
      status: 'available',
      description: 'Intensive course covering data analysis, visualization, and machine learning basics.'
    },
    {
      id: '9',
      title: 'DevOps Best Practices',
      type: 'pdf',
      status: 'available',
      description: 'Guide to implementing effective DevOps practices in your organization.'
    }
  ];
  
  let requests = [];
  let notifications = [];
  
  // Icons for different resource types
  const icons = {
    pdf: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>',
    training: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>',
    course: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg>'
  };
  
  // Get DOM elements
  const searchInput = document.getElementById('searchInput');
  const resourceGrid = document.getElementById('resourceGrid');
  const tabButtons = document.querySelectorAll('.tab-button');
  const addResourceBtn = document.getElementById('addResourceBtn');
  const resourceModal = document.getElementById('resourceModal');
  const resourceForm = document.getElementById('resourceForm');
  const notificationButton = document.getElementById('notificationButton');
  const notificationsPanel = document.getElementById('notificationsPanel');
  const notificationsList = document.querySelector('.notifications-list');
  const notificationBadge = document.querySelector('.notification-badge');
  
  // Create resource card HTML
  function createResourceCard(resource) {
    const statusClass = resource.status.toLowerCase();
    return `
      <div class="resource-card" data-id="${resource.id}">
        <div class="resource-actions">
          <button class="action-button edit" title="Edit">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
          </button>
          <button class="action-button delete" title="Delete">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        </div>
        <div class="resource-header">
          <div class="resource-icon">
            ${icons[resource.type]}
          </div>
          <h3 class="resource-title">${resource.title}</h3>
        </div>
        <p class="resource-description">${resource.description}</p>
        <div class="resource-footer">
          <span class="resource-type">${resource.type}</span>
          <span class="status-badge ${statusClass}">${resource.status}</span>
        </div>
      </div>
    `;
  }
  
  // Render resources based on current tab and search
  function renderResources(searchTerm = '') {
    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    const searchLower = searchTerm.toLowerCase();
    
    let displayResources;
    if (activeTab === 'all') {
      displayResources = resources;
    } else {
      displayResources = resources.filter(resource => resource.status.toLowerCase() === activeTab);
    }
  
    // Apply search filter
    displayResources = displayResources.filter(resource =>
      resource.title.toLowerCase().includes(searchLower) ||
      resource.description.toLowerCase().includes(searchLower)
    );
  
    resourceGrid.innerHTML = displayResources.length
      ? displayResources.map(resource => createResourceCard(resource)).join('')
      : `<div class="no-resources">
          <p>${searchTerm ? 'No resources found matching your search.' : 'No resources available.'}</p>
         </div>`;
  }
  
  // Add new notification
  function addNotification(title, message) {
    const notification = {
      id: Date.now(),
      title,
      message,
      time: new Date(),
      read: false
    };
    
    notifications.unshift(notification);
    updateNotificationBadge();
    renderNotifications();
    
    // Show toast notification
    showToast(`${title}: ${message}`);
  }
  
  // Update notification badge
  function updateNotificationBadge() {
    const unreadCount = notifications.filter(n => !n.read).length;
    notificationBadge.textContent = unreadCount;
    notificationBadge.style.display = unreadCount ? 'flex' : 'none';
  }
  
  // Render notifications
  function renderNotifications() {
    notificationsList.innerHTML = notifications.length
      ? notifications.map(notification => `
          <div class="notification-item" data-id="${notification.id}">
            <div class="notification-header">
              <span class="notification-title">${notification.title}</span>
              <span class="notification-time">${formatTime(notification.time)}</span>
            </div>
            <p class="notification-message">${notification.message}</p>
          </div>
        `).join('')
      : '<div class="no-notifications">No notifications</div>';
  }
  
  // Format time for notifications
  function formatTime(date) {
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  }
  
  // Show toast notification
  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'notification';
    toast.textContent = message;
    document.body.appendChild(toast);
  
    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
  
  // Initialize the dashboard
  function initDashboard() {
    // Initial render
    renderResources();
    updateNotificationBadge();
  
    // Search functionality
    searchInput.addEventListener('input', (e) => {
      renderResources(e.target.value);
    });
  
    // Tab functionality
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        searchInput.value = '';
        renderResources();
      });
    });
  
    // Add resource button
    addResourceBtn.addEventListener('click', () => {
      resourceForm.reset();
      resourceModal.classList.add('active');
    });
  
    // Modal close button
    document.querySelector('.close-button').addEventListener('click', () => {
      resourceModal.classList.remove('active');
    });
  
    // Form submission
    resourceForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const formData = new FormData(resourceForm);
      const newResource = {
        id: Date.now().toString(),
        title: formData.get('title'),
        type: formData.get('type'),
        description: formData.get('description'),
        status: 'available'
      };
      
      resources.push(newResource);
      addNotification('New Resource Added', `"${newResource.title}" has been added to the resources.`);
      
      resourceModal.classList.remove('active');
      renderResources();
    });
  
    // Resource grid actions
    resourceGrid.addEventListener('click', (e) => {
      const card = e.target.closest('.resource-card');
      if (!card) return;
      
      const resourceId = card.dataset.id;
      const resource = resources.find(r => r.id === resourceId);
      
      if (e.target.closest('.action-button.edit')) {
        // Populate form with resource data
        document.getElementById('title').value = resource.title;
        document.getElementById('type').value = resource.type;
        document.getElementById('description').value = resource.description;
        
        resourceModal.classList.add('active');
      } else if (e.target.closest('.action-button.delete')) {
        if (confirm('Are you sure you want to delete this resource?')) {
          resources = resources.filter(r => r.id !== resourceId);
          addNotification('Resource Deleted', `"${resource.title}" has been removed.`);
          renderResources();
        }
      }
    });
  
    // Notifications panel toggle
    notificationButton.addEventListener('click', () => {
      notificationsPanel.classList.toggle('hidden');
      if (!notificationsPanel.classList.contains('hidden')) {
        notifications.forEach(n => n.read = true);
        updateNotificationBadge();
        renderNotifications();
      }
    });
  
    // Clear all notifications
    document.querySelector('.clear-all-button').addEventListener('click', () => {
      notifications = [];
      updateNotificationBadge();
      renderNotifications();
    });
  
    // Click outside to close panels
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#notificationsPanel') && !e.target.closest('#notificationButton')) {
        notificationsPanel.classList.add('hidden');
      }
    });
  
    // Simulate some initial notifications
    addNotification('Welcome', 'Welcome to the admin dashboard! You can manage all learning resources here.');
    addNotification('System Update', 'The resource management system has been updated with new features.');
  }
  
  // Initialize when DOM is loaded
  document.addEventListener('DOMContentLoaded', initDashboard);