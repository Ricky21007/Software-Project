const Resource = require('../models/resource');

exports.getResources = async (req, res) => {
    const resources = await Resource.find();
    res.json(resources);
};
