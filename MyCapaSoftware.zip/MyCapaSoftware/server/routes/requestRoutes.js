const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const Request = require('../models/request');
const Resource = require('../models/resource');
const router = express.Router();

// User Request Resource
router.post('/request', authMiddleware, async (req, res) => {
    const { resourceId } = req.body;
    const resource = await Resource.findById(resourceId);
    if (!resource) return res.status(404).send('Resource not found');

    const request = new Request({
        userId: req.user._id,
        resourceId,
    });

    await request.save();
    res.status(201).send('Request submitted');
});

// Admin Approve/Reject Request
router.put('/requests/:id/approve', authMiddleware, async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Access denied');

    const request = await Request.findById(req.params.id);
    if (!request) return res.status(404).send('Request not found');

    request.status = 'approved';
    request.adminComments = req.body.comments;
    await request.save();
    res.send('Request approved');
});

router.put('/requests/:id/reject', authMiddleware, async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Access denied');

    const request = await Request.findById(req.params.id);
    if (!request) return res.status(404).send('Request not found');

    request.status = 'rejected';
    request.adminComments = req.body.comments;
    await request.save();
    res.send('Request rejected');
});

module.exports = router;
