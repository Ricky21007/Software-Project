const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const Resource = require('../models/resource');
const router = express.Router();

// Create Resource (Admin)
router.post('/admin/uploadResource', authMiddleware, async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Access denied');

    const { title, description, type } = req.body;
    const resource = new Resource({ title, description, type });
    await resource.save();
    res.status(201).send('Resource uploaded');
});

// Get all resources
router.get('/resources', async (req, res) => {
    const resources = await Resource.find();
    res.json(resources);
});

module.exports = router;
