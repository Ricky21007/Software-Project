// Resource data
const resources = [
    {
      id: '1',
      title: 'Advanced JavaScript Techniques',
      type: 'pdf',
      status: 'available',
      description: 'Comprehensive guide to modern JavaScript development patterns.'
    },
    {
      id: '2',
      title: 'React Performance Workshop',
      type: 'training',
      status: 'available',
      description: 'Live training session on optimizing React applications.'
    },
    {
      id: '3',
      title: 'Full Stack Development',
      type: 'course',
      status: 'available',
      description: 'Complete course covering both frontend and backend development.'
    },
    {
      id: '4',
      title: 'UI/UX Design Principles',
      type: 'pdf',
      status: 'available',
      description: 'Essential principles of modern user interface and experience design.'
    },
    {
      id: '5',
      title: 'Cloud Architecture Fundamentals',
      type: 'course',
      status: 'available',
      description: 'Learn the basics of cloud architecture and deployment strategies.'
    },
    {
      id: '6',
      title: 'Agile Development Workshop',
      type: 'training',
      status: 'available',
      description: 'Interactive workshop on agile methodologies and best practices.'
    },
    {
      id: '7',
      title: 'Cybersecurity Essentials',
      type: 'pdf',
      status: 'available',
      description: 'Comprehensive guide to modern security practices and threat prevention.'
    },
    {
      id: '8',
      title: 'Data Science Bootcamp',
      type: 'course',
      status: 'available',
      description: 'Intensive course covering data analysis, visualization, and machine learning basics.'
    },
    {
      id: '9',
      title: 'DevOps Best Practices',
      type: 'pdf',
      status: 'available',
      description: 'Guide to implementing effective DevOps practices in your organization.'
    }
  ];
  
  // User's requested resources
  let myRequests = [];
  
  // Get DOM elements
  const searchInput = document.getElementById('searchInput');
  const resourceGrid = document.getElementById('resourceGrid');
  const tabButtons = document.querySelectorAll('.tab-button');
  
  // Icons for different resource types
  const icons = {
    pdf: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>',
    training: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>',
    course: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg>'
  };
  
  // Create resource card HTML
  function createResourceCard(resource, isRequest = false) {
    return `
      <div class="resource-card" data-id="${resource.id}">
        <div class="resource-header">
          <div class="resource-icon">
            ${icons[resource.type]}
          </div>
          <h3 class="resource-title">${resource.title}</h3>
        </div>
        <p class="resource-description">${resource.description}</p>
        <div class="resource-footer">
          <span class="resource-type">${resource.type}</span>
          ${isRequest ? `
            <button class="cancel-button">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
              Cancel Request
            </button>
          ` : `
            <button class="request-button">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
              Request Access
            </button>
          `}
        </div>
      </div>
    `;
  }
  
  // Render resources based on current tab and search
  function renderResources(searchTerm = '') {
    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    const searchLower = searchTerm.toLowerCase();
    
    let displayResources;
    if (activeTab === 'resources') {
      displayResources = resources.filter(resource => 
        !myRequests.find(req => req.id === resource.id) &&
        (resource.title.toLowerCase().includes(searchLower) ||
         resource.description.toLowerCase().includes(searchLower))
      );
      resourceGrid.innerHTML = displayResources
        .map(resource => createResourceCard(resource, false))
        .join('');
    } else {
      displayResources = myRequests.filter(resource =>
        resource.title.toLowerCase().includes(searchLower) ||
        resource.description.toLowerCase().includes(searchLower)
      );
      resourceGrid.innerHTML = displayResources
        .map(resource => createResourceCard(resource, true))
        .join('');
    }
  
    // Show message if no resources found
    if (displayResources.length === 0) {
      resourceGrid.innerHTML = `
        <div class="no-resources">
          <p>${searchTerm ? 'No resources found matching your search.' : 'No resources available.'}</p>
        </div>
      `;
    }
  }
  
  // Initialize the dashboard
  function initDashboard() {
    // Initial render
    renderResources();
  
    // Search functionality
    searchInput.addEventListener('input', (e) => {
      renderResources(e.target.value);
    });
  
    // Tab functionality
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        searchInput.value = ''; // Clear search when switching tabs
        renderResources();
      });
    });
  
    // Request/Cancel button functionality
    resourceGrid.addEventListener('click', (e) => {
      const requestBtn = e.target.closest('.request-button');
      const cancelBtn = e.target.closest('.cancel-button');
      const card = e.target.closest('.resource-card');
      
      if (!card) return;
      
      const resourceId = card.dataset.id;
      const resource = resources.find(r => r.id === resourceId);
  
      if (requestBtn && resource) {
        // Add to my requests
        if (!myRequests.find(r => r.id === resourceId)) {
          myRequests.push(resource);
          showNotification(`Request submitted for: ${resource.title}`);
          renderResources(searchInput.value);
        }
      } else if (cancelBtn) {
        // Remove from my requests
        myRequests = myRequests.filter(r => r.id !== resourceId);
        showNotification(`Request cancelled for: ${resource.title}`);
        renderResources(searchInput.value);
      }
    });
  }
  
  // Show notification
  function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
  
    // Remove notification after 3 seconds
    setTimeout(() => {
      notification.remove();
    }, 3000);
  }
  
  // Initialize when DOM is loaded
  document.addEventListener('DOMContentLoaded', initDashboard);