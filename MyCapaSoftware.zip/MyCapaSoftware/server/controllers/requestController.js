const Request = require('../models/request');

exports.createRequest = async (req, res) => {
    const { resourceId } = req.body;
    const newRequest = new Request({
        userId: req.user.id,
        resourceId,
    });

    await newRequest.save();
    res.status(201).json({ message: 'Request created' });
};
