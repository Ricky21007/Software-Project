const mongoose = require('mongoose');

const RequestSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    resourceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Resource' },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    adminComments: String,
});

module.exports = mongoose.model('Request', RequestSchema);
